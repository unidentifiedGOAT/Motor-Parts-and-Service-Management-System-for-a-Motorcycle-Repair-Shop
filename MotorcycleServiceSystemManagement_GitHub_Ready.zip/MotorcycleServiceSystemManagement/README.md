# Motorcycle Service System Management

NetBeans Ant Java project.

## Open in NetBeans
1. Extract this ZIP.
2. In NetBeans, choose File > Open Project.
3. Select the `MotorcycleServiceSystemManagement` folder.

## Database setup
- The Java connection code currently expects a local MySQL database named `motorservice_db`.
- The project archive supplied did not include an SQL database export. Export your database separately as a `.sql` file if your instructor requires it.
- Check `src/database/DBConnection.java` and configure the database username/password for your own computer. Do not commit real passwords or private credentials to a public repository.
- The project references MySQL Connector/J 9.4.0 through a local Windows file path. That JAR was not included in the supplied ZIP. Add the MySQL Connector/J library in NetBeans on the computer where you open the project.

## GitHub
This prepared copy excludes generated `build/` output and machine-specific `nbproject/private/` settings. Keep your original project folder as a backup.
