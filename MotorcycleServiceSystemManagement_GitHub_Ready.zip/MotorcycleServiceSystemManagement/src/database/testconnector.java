package database;

import java.sql.Connection;

public class testconnector {

    public static void main(String[] args) {

        Connection conn = DBConnection.getConnection();

        if (conn != null) {
            System.out.println("CONNECTED TO DATABASE!");
        } else {
            System.out.println("CONNECTION FAILED!");
        }
    }
}