package Gui;
import database.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
public class ArchivePanel extends javax.swing.JPanel {

    private void loadCustomerArchive() {

    String sql = "SELECT * FROM customer_archive";

    try {
        Connection conn = DBConnection.getConnection();
        PreparedStatement pst = conn.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();

        DefaultTableModel model =
                (DefaultTableModel) archiveTable.getModel();

        model.setColumnIdentifiers(new String[]{
            "ID",
            "FIRST NAME",
            "LAST NAME",
            "CONTACT",
            "ADDRESS",
            "DATE REMOVED"
        });

        model.setRowCount(0);

        while (rs.next()) {

            model.addRow(new Object[]{
                rs.getInt("customer_id"),
                rs.getString("first_name"),
                rs.getString("last_name"),
                rs.getString("contact_number"),
                rs.getString("address"),
                rs.getTimestamp("date_removed")
            });
        }

        rs.close();
        pst.close();
        conn.close();

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
                this,
                "Error loading archive: " + e.getMessage()
        );
    }
}
    
    private void loadMotorcycleArchive() {

    String sql = "SELECT * FROM motorcycle_archive";

    try {
        Connection conn = DBConnection.getConnection();
        PreparedStatement pst = conn.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();

        DefaultTableModel model =
                (DefaultTableModel) archiveTable.getModel();

        model.setColumnIdentifiers(new String[]{
            "ID",
            "CUSTOMER ID",
            "BRAND",
            "MODEL & YEAR",
            "PLATE NUMBER",
            "DATE REMOVED"
        });

        model.setRowCount(0);

        while (rs.next()) {

            model.addRow(new Object[]{
                rs.getInt("motorcycle_id"),
                rs.getInt("customer_id"),
                rs.getString("brand"),
                rs.getString("model&Year"),
                rs.getString("plate_number"),
                rs.getTimestamp("date_removed")
            });
        }

        rs.close();
        pst.close();
        conn.close();

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
                this,
                "Error loading motorcycle archive: "
                + e.getMessage()
        );
    }
}
    
    private void loadMechanicArchive() {

    String sql = "SELECT * FROM mechanic_archive";

    try {
        Connection conn = DBConnection.getConnection();
        PreparedStatement pst = conn.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();

        DefaultTableModel model =
                (DefaultTableModel) archiveTable.getModel();

        model.setColumnIdentifiers(new String[]{
            "ID",
            "FIRST NAME",
            "LAST NAME",
            "CONTACT",
            "SPECIALIZATION",
            "DATE REMOVED"
        });

        model.setRowCount(0);

        while (rs.next()) {

            model.addRow(new Object[]{
                rs.getInt("mechanic_id"),
                rs.getString("first_name"),
                rs.getString("last_name"),
                rs.getString("contact_number"),
                rs.getString("specialization"),
                rs.getTimestamp("date_removed")
            });
        }

        rs.close();
        pst.close();
        conn.close();

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
                this,
                "Error loading mechanic archive: "
                + e.getMessage()
        );
    }
}
    
    private void loadPartsArchive() {

    String sql = "SELECT * FROM parts_archive";

    try {
        Connection conn = DBConnection.getConnection();
        PreparedStatement pst = conn.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();

        DefaultTableModel model =
                (DefaultTableModel) archiveTable.getModel();

        model.setColumnIdentifiers(new String[]{
            "ID",
            "PART NAME",
            "CATEGORY",
            "BRAND",
            "PRICE",
            "STOCK QUANTITY",
            "DATE REMOVED"
        });

        model.setRowCount(0);

        while (rs.next()) {

            model.addRow(new Object[]{
                rs.getInt("part_id"),
                rs.getString("part_name"),
                rs.getString("category"),
                rs.getString("brand"),
                rs.getDouble("price"),
                rs.getInt("stock_quantity"),
                rs.getTimestamp("date_removed")
            });
        }

        rs.close();
        pst.close();
        conn.close();

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
                this,
                "Error loading parts archive: "
                + e.getMessage()
        );
    }
}
    
    private void loadTransactionArchive() {

    String sql = "SELECT * FROM service_transaction_archive";

    try {
        Connection conn = DBConnection.getConnection();
        PreparedStatement pst = conn.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();

        DefaultTableModel model =
                (DefaultTableModel) archiveTable.getModel();

        model.setColumnIdentifiers(new String[]{
            "ID",
            "MOTORCYCLE ID",
            "MECHANIC ID",
            "DATE",
            "TOTAL AMOUNT",
            "STATUS",
            "DATE REMOVED"
        });

        model.setRowCount(0);

        while (rs.next()) {

            model.addRow(new Object[]{
                rs.getInt("transaction_id"),
                rs.getInt("motorcycle_id"),
                rs.getInt("mechanic_id"),
                rs.getDate("transaction_date"),
                rs.getDouble("total_amount"),
                rs.getString("status"),
                rs.getTimestamp("date_removed")
            });
        }

        rs.close();
        pst.close();
        conn.close();

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
                this,
                "Error loading transaction archive: "
                + e.getMessage()
        );
    }
}
    
    private void loadPaymentArchive() {

    String sql = "SELECT * FROM payment_archive";

    try {
        Connection conn = DBConnection.getConnection();
        PreparedStatement pst = conn.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();

        DefaultTableModel model =
                (DefaultTableModel) archiveTable.getModel();

        model.setColumnIdentifiers(new String[]{
            "ID",
            "TRANSACTION ID",
            "PAYMENT DATE",
            "AMOUNT PAID",
            "PAYMENT METHOD",
            "DATE REMOVED"
        });

        model.setRowCount(0);

        while (rs.next()) {

            model.addRow(new Object[]{
                rs.getInt("payment_id"),
                rs.getInt("transaction_id"),
                rs.getDate("payment_date"),
                rs.getDouble("amount_paid"),
                rs.getString("payment_method"),
                rs.getTimestamp("date_removed")
            });
        }

        rs.close();
        pst.close();
        conn.close();

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
                this,
                "Error loading payment archive: "
                + e.getMessage()
        );
    }
}
    
    private void loadServiceArchive() {

    String sql = "SELECT * FROM service_archive";

    try {
        Connection conn = DBConnection.getConnection();
        PreparedStatement pst = conn.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();

        DefaultTableModel model =
                (DefaultTableModel) archiveTable.getModel();

        model.setColumnIdentifiers(new String[]{
            "ID",
            "SERVICE NAME",
            "DESCRIPTION",
            "SERVICE FEE",
            "DATE REMOVED"
        });

        model.setRowCount(0);

        while (rs.next()) {

            model.addRow(new Object[]{
                rs.getInt("service_id"),
                rs.getString("service_name"),
                rs.getString("description"),
                rs.getDouble("service_fee"),
                rs.getTimestamp("date_removed")
            });
        }

        rs.close();
        pst.close();
        conn.close();

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
                this,
                "Error loading service archive: "
                + e.getMessage()
        );
    }
}
    public ArchivePanel() {
        initComponents();
        loadCustomerArchive();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        searchArchive_txt = new javax.swing.JTextField();
        searchArchive_btn = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        archiveTable = new javax.swing.JTable();
        restoreArchive_btn = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        recordType_combo = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jLabel2.setFont(new java.awt.Font("Segoe UI Historic", 1, 14)); // NOI18N
        jLabel2.setText("Search:");

        searchArchive_txt.addActionListener(this::searchArchive_txtActionPerformed);

        searchArchive_btn.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        searchArchive_btn.setText("SEARCH");
        searchArchive_btn.addActionListener(this::searchArchive_btnActionPerformed);

        archiveTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "FIRST NAME", "LAST NAME", "CONTACT #", "SPECIALIZATION"
            }
        ));
        jScrollPane2.setViewportView(archiveTable);

        restoreArchive_btn.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        restoreArchive_btn.setText("RESTORE");
        restoreArchive_btn.addActionListener(this::restoreArchive_btnActionPerformed);

        jLabel1.setFont(new java.awt.Font("Segoe UI Variable", 3, 36)); // NOI18N
        jLabel1.setText("ARCHIVE");

        jLabel3.setFont(new java.awt.Font("Segoe UI Emoji", 1, 12)); // NOI18N
        jLabel3.setText("RECORD TABLE:");

        recordType_combo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Customer", "Motorcycle", "Mechanic", "Service", "Parts", "Transaction", "Payment" }));
        recordType_combo.addActionListener(this::recordType_comboActionPerformed);

        jLabel4.setFont(new java.awt.Font("Segoe UI Historic", 1, 14)); // NOI18N
        jLabel4.setText("Record type:");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(restoreArchive_btn)
                    .addComponent(jLabel3)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 781, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addGap(15, 15, 15)
                        .addComponent(recordType_combo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(18, 18, 18)
                        .addComponent(searchArchive_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15)
                        .addComponent(searchArchive_btn))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(258, 258, 258)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(50, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(0, 0, 0)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(recordType_combo, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(searchArchive_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(searchArchive_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15)
                .addComponent(jLabel3)
                .addGap(0, 0, 0)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(restoreArchive_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(12, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void restoreArchive_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_restoreArchive_btnActionPerformed
        // TODO add your handling code here:
 String type = recordType_combo.getSelectedItem().toString();

int selectedRow = archiveTable.getSelectedRow();

if (selectedRow == -1) {
    JOptionPane.showMessageDialog(
            this,
            "Please select a record to restore."
    );
    return;
}

int confirm = JOptionPane.showConfirmDialog(
        this,
        "Restore this " + type + "?",
        "Confirm Restore",
        JOptionPane.YES_NO_OPTION
);

if (confirm != JOptionPane.YES_OPTION) {
    return;
}

try {

    Connection conn = DBConnection.getConnection();

    int id = (int) archiveTable.getValueAt(selectedRow, 0);

    switch (type) {

        case "Customer":

            String customerInsert =
                    "INSERT INTO customer "
                    + "(customer_id, first_name, last_name, "
                    + "contact_number, address) "
                    + "SELECT customer_id, first_name, last_name, "
                    + "contact_number, address "
                    + "FROM customer_archive "
                    + "WHERE customer_id = ?";

            String customerDelete =
                    "DELETE FROM customer_archive "
                    + "WHERE customer_id = ?";

            PreparedStatement customerPst =
                    conn.prepareStatement(customerInsert);

            customerPst.setInt(1, id);
            customerPst.executeUpdate();

            PreparedStatement customerDeletePst =
                    conn.prepareStatement(customerDelete);

            customerDeletePst.setInt(1, id);
            customerDeletePst.executeUpdate();

            customerPst.close();
            customerDeletePst.close();

            break;


        case "Motorcycle":

            String motorcycleInsert =
                    "INSERT INTO motorcycle "
                    + "(motorcycle_id, customer_id, brand, "
                    + "`model&Year`, plate_number) "
                    + "SELECT motorcycle_id, customer_id, brand, "
                    + "`model&Year`, plate_number "
                    + "FROM motorcycle_archive "
                    + "WHERE motorcycle_id = ?";

            String motorcycleDelete =
                    "DELETE FROM motorcycle_archive "
                    + "WHERE motorcycle_id = ?";

            PreparedStatement motorcyclePst =
                    conn.prepareStatement(motorcycleInsert);

            motorcyclePst.setInt(1, id);
            motorcyclePst.executeUpdate();

            PreparedStatement motorcycleDeletePst =
                    conn.prepareStatement(motorcycleDelete);

            motorcycleDeletePst.setInt(1, id);
            motorcycleDeletePst.executeUpdate();

            motorcyclePst.close();
            motorcycleDeletePst.close();

            break;


        case "Mechanic":

            String mechanicInsert =
                    "INSERT INTO mechanic "
                    + "(mechanic_id, first_name, last_name, "
                    + "contact_number, specialization) "
                    + "SELECT mechanic_id, first_name, last_name, "
                    + "contact_number, specialization "
                    + "FROM mechanic_archive "
                    + "WHERE mechanic_id = ?";

            String mechanicDelete =
                    "DELETE FROM mechanic_archive "
                    + "WHERE mechanic_id = ?";

            PreparedStatement mechanicPst =
                    conn.prepareStatement(mechanicInsert);

            mechanicPst.setInt(1, id);
            mechanicPst.executeUpdate();

            PreparedStatement mechanicDeletePst =
                    conn.prepareStatement(mechanicDelete);

            mechanicDeletePst.setInt(1, id);
            mechanicDeletePst.executeUpdate();

            mechanicPst.close();
            mechanicDeletePst.close();

            break;


        case "Service":

            String serviceInsert =
                    "INSERT INTO service "
                    + "(service_id, service_name, description, service_fee) "
                    + "SELECT service_id, service_name, description, service_fee "
                    + "FROM service_archive "
                    + "WHERE service_id = ?";

            String serviceDelete =
                    "DELETE FROM service_archive "
                    + "WHERE service_id = ?";

            PreparedStatement servicePst =
                    conn.prepareStatement(serviceInsert);

            servicePst.setInt(1, id);
            servicePst.executeUpdate();

            PreparedStatement serviceDeletePst =
                    conn.prepareStatement(serviceDelete);

            serviceDeletePst.setInt(1, id);
            serviceDeletePst.executeUpdate();

            servicePst.close();
            serviceDeletePst.close();

            break;


        case "Parts":

            String partsInsert =
                    "INSERT INTO parts "
                    + "(part_id, part_name, category, brand, "
                    + "price, stock_quantity) "
                    + "SELECT part_id, part_name, category, brand, "
                    + "price, stock_quantity "
                    + "FROM parts_archive "
                    + "WHERE part_id = ?";

            String partsDelete =
                    "DELETE FROM parts_archive "
                    + "WHERE part_id = ?";

            PreparedStatement partsPst =
                    conn.prepareStatement(partsInsert);

            partsPst.setInt(1, id);
            partsPst.executeUpdate();

            PreparedStatement partsDeletePst =
                    conn.prepareStatement(partsDelete);

            partsDeletePst.setInt(1, id);
            partsDeletePst.executeUpdate();

            partsPst.close();
            partsDeletePst.close();

            break;


        case "Transaction":

            String transactionInsert =
                    "INSERT INTO service_transaction "
                    + "(transaction_id, motorcycle_id, mechanic_id, "
                    + "transaction_date, total_amount, status) "
                    + "SELECT transaction_id, motorcycle_id, mechanic_id, "
                    + "transaction_date, total_amount, status "
                    + "FROM service_transaction_archive "
                    + "WHERE transaction_id = ?";

            String transactionDelete =
                    "DELETE FROM service_transaction_archive "
                    + "WHERE transaction_id = ?";

            PreparedStatement transactionPst =
                    conn.prepareStatement(transactionInsert);

            transactionPst.setInt(1, id);
            transactionPst.executeUpdate();

            PreparedStatement transactionDeletePst =
                    conn.prepareStatement(transactionDelete);

            transactionDeletePst.setInt(1, id);
            transactionDeletePst.executeUpdate();

            transactionPst.close();
            transactionDeletePst.close();

            break;


        case "Payment":

            String paymentInsert =
                    "INSERT INTO payment "
                    + "(payment_id, transaction_id, payment_date, "
                    + "amount_paid, payment_method) "
                    + "SELECT payment_id, transaction_id, payment_date, "
                    + "amount_paid, payment_method "
                    + "FROM payment_archive "
                    + "WHERE payment_id = ?";

            String paymentDelete =
                    "DELETE FROM payment_archive "
                    + "WHERE payment_id = ?";

            PreparedStatement paymentPst =
                    conn.prepareStatement(paymentInsert);

            paymentPst.setInt(1, id);
            paymentPst.executeUpdate();

            PreparedStatement paymentDeletePst =
                    conn.prepareStatement(paymentDelete);

            paymentDeletePst.setInt(1, id);
            paymentDeletePst.executeUpdate();

            paymentPst.close();
            paymentDeletePst.close();

            break;
    }

    conn.close();

    JOptionPane.showMessageDialog(
            this,
            type + " Restored!"
    );

    // Reload the selected archive
    recordType_comboActionPerformed(null);

} catch (SQLException e) {

    JOptionPane.showMessageDialog(
            this,
            "Error restoring " + type + ": "
            + e.getMessage()
    );
}
    }//GEN-LAST:event_restoreArchive_btnActionPerformed

    private void searchArchive_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchArchive_btnActionPerformed
        // TODO add your handling code here:
       String search = searchArchive_txt.getText().trim();

if (search.isEmpty()) {
    loadCustomerArchive();
    return;
}

String sql =
        "SELECT * FROM customer_archive "
        + "WHERE CAST(customer_id AS CHAR) LIKE ? "
        + "OR first_name LIKE ? "
        + "OR last_name LIKE ? "
        + "OR contact_number LIKE ? "
        + "OR address LIKE ?";

try {
    Connection conn = DBConnection.getConnection();
    PreparedStatement pst = conn.prepareStatement(sql);

    String keyword = "%" + search + "%";

    pst.setString(1, keyword);
    pst.setString(2, keyword);
    pst.setString(3, keyword);
    pst.setString(4, keyword);
    pst.setString(5, keyword);

    ResultSet rs = pst.executeQuery();

    DefaultTableModel model =
            (DefaultTableModel) archiveTable.getModel();

    model.setRowCount(0);

    while (rs.next()) {

        model.addRow(new Object[]{
            rs.getInt("customer_id"),
            rs.getString("first_name"),
            rs.getString("last_name"),
            rs.getString("contact_number"),
            rs.getString("address"),
            rs.getTimestamp("date_removed")
        });
    }

    rs.close();
    pst.close();
    conn.close();

} catch (SQLException e) {

    JOptionPane.showMessageDialog(
            this,
            "Error searching archive: " + e.getMessage()
    );
}
    }//GEN-LAST:event_searchArchive_btnActionPerformed

    private void searchArchive_txtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchArchive_txtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_searchArchive_txtActionPerformed

    private void recordType_comboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_recordType_comboActionPerformed
        // TODO add your handling code here:
    String type = recordType_combo.getSelectedItem().toString();

    switch (type) {

        case "Customer":
            loadCustomerArchive();
            break;

        case "Motorcycle":
            loadMotorcycleArchive();
            break;

        case "Mechanic":
            loadMechanicArchive();
            break;

        case "Service":
            loadServiceArchive();
            break;

        case "Parts":
            loadPartsArchive();
            break;

        case "Transaction":
            loadTransactionArchive();
            break;

        case "Payment":
            loadPaymentArchive();
            break;
    }
    }//GEN-LAST:event_recordType_comboActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable archiveTable;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JComboBox<String> recordType_combo;
    private javax.swing.JButton restoreArchive_btn;
    private javax.swing.JButton searchArchive_btn;
    private javax.swing.JTextField searchArchive_txt;
    // End of variables declaration//GEN-END:variables
}
